<?php
var_dump($_SERVER);
var_dump($_EMBED);
