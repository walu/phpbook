/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2012 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

/* $Id$ */

#ifndef PHP_SAMPLE0_H
#define PHP_SAMPLE0_H

extern zend_module_entry sample0_module_entry;
#define phpext_sample0_ptr &sample0_module_entry

#ifdef PHP_WIN32
#	define PHP_SAMPLE0_API __declspec(dllexport)
#elif defined(__GNUC__) && __GNUC__ >= 4
#	define PHP_SAMPLE0_API __attribute__ ((visibility("default")))
#else
#	define PHP_SAMPLE0_API
#endif

#ifdef ZTS
#include "TSRM.h"
#endif

/* 模块钩子函数 */
PHP_MINIT_FUNCTION(sample0);
PHP_MSHUTDOWN_FUNCTION(sample0);
PHP_RINIT_FUNCTION(sample0);
PHP_RSHUTDOWN_FUNCTION(sample0);
PHP_MINFO_FUNCTION(sample0);

/* 用户空间函数 */
PHP_FUNCTION(sample0_fopen);
PHP_FUNCTION(sample0_fsockopen);
PHP_FUNCTION(sample0_fgetc);
PHP_FUNCTION(sample0_fread);
PHP_FUNCTION(sample0_fgetline);
PHP_FUNCTION(sample0_fgets);
PHP_FUNCTION(sample0_fgetrecord);
PHP_FUNCTION(sample0_readdir);
PHP_FUNCTION(sample0_fwrite);
PHP_FUNCTION(sample0_fwritestring);
PHP_FUNCTION(sample0_fputc);
PHP_FUNCTION(sample0_fputs);
PHP_FUNCTION(sample0_fprintf);
PHP_FUNCTION(sample0_fseek);
PHP_FUNCTION(sample0_frewind);
PHP_FUNCTION(sample0_frewinddir);
PHP_FUNCTION(sample0_ftell);
PHP_FUNCTION(sample0_fstat);
PHP_FUNCTION(sample0_stat_path);

/* 全局空间 */
ZEND_BEGIN_MODULE_GLOBALS(sample0)
	long  global_value;
	char *global_string;
ZEND_END_MODULE_GLOBALS(sample0)

/* 全局空间访问宏 */
#ifdef ZTS
#define SAMPLE0_G(v) TSRMG(sample0_globals_id, zend_sample0_globals *, v)
#else
#define SAMPLE0_G(v) (sample0_globals.v)
#endif

#endif	/* PHP_SAMPLE0_H */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
