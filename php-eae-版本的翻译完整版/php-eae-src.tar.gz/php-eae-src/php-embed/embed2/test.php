<?php
var_dump(get_loaded_extensions());
