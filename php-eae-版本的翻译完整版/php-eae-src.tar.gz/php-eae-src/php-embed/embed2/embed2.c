#include <sapi/embed/php_embed.h>

#ifdef ZTS
	void ***tsrm_ls;
#endif

zend_module_entry php_mymod_module_entry = {
	STANDARD_MODULE_HEADER,
	"mymod", /* extension name */
	NULL, /* function entries */
	NULL, /* MINIT */
	NULL, /* MSHUTDOWN */
	NULL, /* RINIT */
	NULL, /* RSHUTDOWN */
	NULL, /* MINFO */
	"1.0", /* version */
	STANDARD_MODULE_PROPERTIES
};

static int (*original_embed_startup)(struct _sapi_module_struct *sapi_module);
static int embed4_startup_callback(struct _sapi_module_struct *sapi_module) {
	if ( original_embed_startup(sapi_module) == FAILURE ) {
		return FAILURE;
	}
	zend_alter_ini_entry("max_execution_time", sizeof("max_execution_time"), "15", sizeof("15") - 1, PHP_INI_SYSTEM, PHP_INI_STAGE_ACTIVATE);
	zend_alter_ini_entry("safe_mode", sizeof("safe_mode"), "On", sizeof("On") - 1, PHP_INI_SYSTEM, PHP_INI_STAGE_ACTIVATE);
	return SUCCESS;
}

static void startup_php(void) {
	int		argc		= 1;
	char	*argv[2]	= {"embed4", NULL};

	original_embed_startup		= php_embed_module.startup;
	php_embed_module.startup	= embed4_startup_callback;

	php_embed_init(argc, argv PTSRMLS_CC);

	zend_startup_module(&php_mymod_module_entry);
}
static void shutdown_php(void) {
	php_embed_shutdown(TSRMLS_C);
}
static void execute_php(char *filename) {
	zend_first_try {
		char	*include_script;
		spprintf(&include_script, 0, "include '%s';", filename);
		zend_eval_string(include_script, NULL, filename TSRMLS_CC);
		efree(include_script);
	} zend_end_try();
}

int main(int argc, char *argv[]) {
	char	*filename;

	if ( argc <= 1 ) {
		fprintf(stderr, "Usage: %s <filename.php> <arguments>\n", argv[1]);
		return -1;
	}

	filename	= argv[1];

	startup_php();
	execute_php(argv[1]);
	shutdown_php();

	/* 忽略第0个参数 */
	argc --;
	argv ++;

/*
	PHP_EMBED_START_BLOCK(argc, argv)
		char	*include_script;

		spprintf(&include_script, 0, "include '%s';", filename);
		zend_eval_string(include_script, NULL, filename TSRMLS_CC);
		efree(include_script);
	PHP_EMBED_END_BLOCK()
*/

/*
	PHP_EMBED_START_BLOCK(argc, argv)
		char	*command;
		zval	retval;

		spprintf(&command, 0, "nl2br('%s');", argv[1]);
		zend_eval_string(command, &retval, "nl2br() execution" TSRMLS_CC);
		efree(command);
		printf("out: %s\n", Z_STRVAL(retval));
		zval_dtor(&retval);
	PHP_EMBED_END_BLOCK()
*/

/*
	PHP_EMBED_START_BLOCK(argc, argv)
		zval	*args[1];
		zval	retval, str, funcname;

		ZVAL_STRING(&funcname, "nl2br", 0);
		args[0]	= &str;
		ZVAL_STRINGL(args[0], "HELLO WORLD!", sizeof("HELLO WORLD!"), 1);
		call_user_function(EG(function_table), NULL, &funcname, &retval, 1, args TSRMLS_CC);

		printf("out: %s\n", Z_STRVAL(retval));

		zval_dtor(args[0]);
		zval_dtor(&retval);
	PHP_EMBED_END_BLOCK()
*/

/*
	PHP_EMBED_START_BLOCK(argc, argv)
		zend_try {
			printf("enter try\n");
			zend_eval_string("$1a = 1;", NULL, "Script Block 1a" TSRMLS_CC);
			zend_bailout();
		} zend_catch {
			printf("enter catch\n");
			zend_eval_string("$a = 1;", NULL, "Script Block 1" TSRMLS_CC);
		} zend_end_try();
		zend_eval_string("var_dump($a);", NULL, "Script Block 2" TSRMLS_CC);
	PHP_EMBED_END_BLOCK()
*/
	
/*
#ifdef ZTS
	void	***tsrm_ls;
#endif
	
	php_embed_init(argc, argv PTSRMLS_CC);
	zend_first_try {
		zend_eval_string("echo 'Hello World!';", NULL, "Embed2 eval'd string" TSRMLS_CC);
	} zend_end_try();
	php_embed_shutdown(TSRMLS_C);
*/

	return 0;
}
