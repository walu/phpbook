/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2012 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

/* $Id$ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_sample0.h"

/* 线程安全的全局空间 */
ZEND_DECLARE_MODULE_GLOBALS(sample0)

/* 函数表 */
const zend_function_entry sample0_functions[] = {
	PHP_FE(sample0_fopen,			NULL)
	PHP_FE(sample0_fsockopen,		NULL)
	PHP_FE(sample0_fgetc,			NULL)
	PHP_FE(sample0_fread,			NULL)
	PHP_FE(sample0_fgetline,		NULL)
	PHP_FE(sample0_fgets,			NULL)
	PHP_FE(sample0_fgetrecord,		NULL)
	PHP_FE(sample0_readdir,			NULL)
	PHP_FE(sample0_fwrite,			NULL)
	PHP_FE(sample0_fwritestring,	NULL)
	PHP_FE(sample0_fputc,			NULL)
	PHP_FE(sample0_fputs,			NULL)
	PHP_FE(sample0_fprintf,			NULL)
	PHP_FE(sample0_fseek,			NULL)
	PHP_FE(sample0_frewind,			NULL)
	PHP_FE(sample0_frewinddir,		NULL)
	PHP_FE(sample0_ftell,			NULL)
	PHP_FE(sample0_fstat,			NULL)
	PHP_FE(sample0_stat_path,		NULL)
	PHP_FE_END
};

/* 模块结构体 */
zend_module_entry sample0_module_entry = {
#if ZEND_MODULE_API_NO >= 20010901
	STANDARD_MODULE_HEADER,
#endif
	"sample0",
	sample0_functions,
	PHP_MINIT(sample0),
	PHP_MSHUTDOWN(sample0),
	PHP_RINIT(sample0),	
	PHP_RSHUTDOWN(sample0),
	PHP_MINFO(sample0),
#if ZEND_MODULE_API_NO >= 20010901
	"0.1", 
#endif
	STANDARD_MODULE_PROPERTIES
};

/* 动态加载入口 */
#ifdef COMPILE_DL_SAMPLE0
ZEND_GET_MODULE(sample0)
#endif

/* php.ini配置指令 */
PHP_INI_BEGIN()
    STD_PHP_INI_ENTRY("sample0.global_value",      "42", PHP_INI_ALL, OnUpdateLong, global_value, zend_sample0_globals, sample0_globals)
    STD_PHP_INI_ENTRY("sample0.global_string", "foobar", PHP_INI_ALL, OnUpdateString, global_string, zend_sample0_globals, sample0_globals)
PHP_INI_END()

/* 全局空间构造器 */
ZEND_MODULE_GLOBALS_CTOR_D(sample0) 
{
	SAMPLE0_G(global_value)		= 0;
	SAMPLE0_G(global_string)	= NULL;
}
/* 全局空间析构器 */
ZEND_MODULE_GLOBALS_DTOR_D(sample0)
{
}

/* 模块启动 */
PHP_MINIT_FUNCTION(sample0)
{
	ZEND_INIT_MODULE_GLOBALS(sample0, ZEND_MODULE_GLOBALS_CTOR_N(sample0), NULL/* ZEND_MODULE_GLOBALS_DTOR_N(sample0) */);
	REGISTER_INI_ENTRIES();
	return SUCCESS;
}

/* 模块终止 */
PHP_MSHUTDOWN_FUNCTION(sample0)
{
	UNREGISTER_INI_ENTRIES();
#ifndef ZTS
	ZEND_MODULE_GLOBALS_DTOR_N(sample0)();
#endif
	return SUCCESS;
}

/* 请求启动 */
PHP_RINIT_FUNCTION(sample0)
{
	return SUCCESS;
}

/* 请求终止 */
PHP_RSHUTDOWN_FUNCTION(sample0)
{
	return SUCCESS;
}

/* phpinfo()输出信息 */
PHP_MINFO_FUNCTION(sample0)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "sample0 support", "enabled");
	php_info_print_table_end();

	DISPLAY_INI_ENTRIES();
}

/* 打开文件 */
PHP_FUNCTION(sample0_fopen)
{
	php_stream	*stream;
	char		*path, *mode;
	int			path_len, mode_len;
	int			options	= ENFORCE_SAFE_MODE | REPORT_ERRORS;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ss", &path, &path_len, &mode, &mode_len) == FAILURE ) {
		RETURN_FALSE;
	}
	
	stream	= php_stream_open_wrapper(path, mode, options, NULL);
	if ( !stream ) {
		RETURN_FALSE;
	}
	php_stream_to_zval(stream, return_value);
}

PHP_FUNCTION(sample0_fsockopen)
{
	php_stream		*stream;
	char			*host, *transport, *errstr = NULL;
	int				host_len, transport_len, implicit_tcp = 1, errcode = 0;
	long			port	= 0;
	int				options	= ENFORCE_SAFE_MODE;
	int				flags	= STREAM_XPORT_CLIENT | STREAM_XPORT_CONNECT;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s|l", 
			&host, &host_len, &port) == FAILURE ) {
		RETURN_FALSE;
	}

	if ( port ) {
		int	implicit_tcp	= 1;
		if ( strstr(host, "://") ) {
			implicit_tcp	= 0;
		}
		transport_len		= spprintf(&transport, 0, "%s%s:%d", 
							implicit_tcp ? "tcp://" : "", host, port);
	} else {
		transport		= host;
		transport_len	= host_len;
	}

	stream	= php_stream_xport_create(transport, transport_len, 
			options, flags, NULL, NULL, NULL, &errstr, &errcode);

	if ( transport != host ) {
		efree(transport);
	}
	if ( errstr ) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "[%d] %s", 
			errcode, errstr);
		efree(errstr);
	}
	if ( !stream ) {
		RETURN_FALSE;
	}
	php_stream_to_zval(stream, return_value);
}

PHP_FUNCTION(sample0_fgetc)
{
	zval		*z;
	php_stream	*stream;
	int			c;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &z) == FAILURE ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, (&z));

	c	= php_stream_getc(stream);

	RETURN_STRINGL((char *)&c, 1, 1);
}

PHP_FUNCTION(sample0_fread)
{
	zval		*z;
	php_stream	*stream;
	long		l;
	char		*buff;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rl", &z, &l) == FAILURE ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, (&z));
	buff	= emalloc(l + 1);
	php_stream_read(stream, buff, l);
	buff[l]	= 0;

	RETURN_STRING(buff, 0);
}

PHP_FUNCTION(sample0_fgetline)
{
	zval		*z;
	php_stream	*stream;
	long		l, rl = 0;
	char		*buff;
	int			argc = ZEND_NUM_ARGS();

	l	= 1024;
	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r|l", &z, &l) == FAILURE ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, (&z));
	if ( argc == 1 ) {
		buff	= php_stream_get_line(stream, NULL, 0, &rl);
		if ( buff == NULL )
			goto failed;
	} else {
		buff	= ecalloc(l + 1, sizeof(char));
		if ( php_stream_get_line(stream, buff, l, &rl) == NULL ) {
			goto failed;
		}
	}

	RETURN_STRINGL(buff, rl, 0);
failed:
	if ( buff != NULL )
		efree(buff);
	RETURN_FALSE;
}

PHP_FUNCTION(sample0_fgets)
{
	zval		*z;
	php_stream	*stream;
	long		l;
	char		*buff;
	int			argc = ZEND_NUM_ARGS();

	l	= 1024;
	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r|l", &z, &l) == FAILURE ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, (&z));
	if ( argc == 1 ) {
		buff	= php_stream_gets(stream, NULL, 0);
		if ( buff == NULL )
			goto failed;
	} else {
		buff	= ecalloc(l + 1, sizeof(char));
		if ( php_stream_gets(stream, buff, l) == NULL ) {
			goto failed;
		}
	}

	RETURN_STRING(buff, 0);
failed:
	if ( buff != NULL )
		efree(buff);
	RETURN_FALSE;
}

PHP_FUNCTION(sample0_fgetrecord)
{
	zval		*z;
	php_stream	*stream;
	long		l, rl = 0;
	char		*buff;

	l	= 1024;
	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r|l", &z, &l) == FAILURE ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, (&z));
	buff	= php_stream_get_record(stream, l, &rl, "\t ", 2 TSRMLS_CC);
	if ( buff == NULL ) 
		goto failed;

	RETURN_STRING(buff, 0);
failed:
	RETURN_FALSE;
}

PHP_FUNCTION(sample0_readdir)
{
	zval				*z;
	php_stream			*stream;
	php_stream_dirent	d;
	char				*name;
	
	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &z) == FAILURE ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, (&z));

	if ( php_stream_readdir(stream, &d) == NULL )
		RETURN_FALSE;

	RETURN_STRING(d.d_name, 1);
}

PHP_FUNCTION(sample0_fwrite)
{
	zval			*z;
	php_stream		*stream;
	char			*buff;
	int				buff_len;
	long			write_len, n_write;
	int				argc = ZEND_NUM_ARGS();

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs|l", &z, &buff, &buff_len, &write_len) == FAILURE ) {
		RETURN_FALSE;
	}

	if ( argc == 2 || write_len > buff_len )
		write_len	= buff_len;
	if ( write_len <= 0 )
		RETURN_LONG(0);

	php_stream_from_zval(stream, &z);
	
	n_write	= php_stream_write(stream, buff, write_len);
	RETURN_LONG(n_write);
}

PHP_FUNCTION(sample0_fwritestring)
{
	zval		*z;
	php_stream	*stream;
	char		*buff;
	int			buff_len;
	long		n_write;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &z, &buff, &buff_len) == FAILURE ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, &z);

	n_write	= php_stream_write_string(stream, buff);
	RETURN_LONG(n_write);
}

PHP_FUNCTION(sample0_fputc)
{
	zval		*z;
	php_stream	*stream;
	char		*buff;
	int			buff_len;
	long		n_write;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &z, &buff, &buff_len) == FAILURE ) {
		RETURN_FALSE;
	}
	if ( buff_len > 1 ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, &z);

	n_write	= php_stream_putc(stream, (int)*buff);
	if ( n_write != 1 ) {
		RETURN_FALSE;
	} else {
		RETURN_TRUE;
	}
}

PHP_FUNCTION(sample0_fputs)
{
	zval		*z;
	php_stream	*stream;
	char		*buff;
	int			buff_len;
	long		ret;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &z, &buff, &buff_len) == FAILURE ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, &z);

	ret	= php_stream_puts(stream, buff);
	RETURN_LONG(ret);
}

PHP_FUNCTION(sample0_fprintf)
{
	zval		*z;
	php_stream	*stream;
	char		*buff;
	int			buff_len;
	long		n_write;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", &z, &buff, &buff_len) == FAILURE) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, &z);

	n_write	= php_stream_printf(stream TSRMLS_CC, "%20s\n", buff);
	RETURN_LONG(n_write);
}

PHP_FUNCTION(sample0_fseek)
{
	zval		*z;
	php_stream	*stream;
	long		offset;
	long		whence = SEEK_SET;
	int			ret;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rl|l", &z, &offset, &whence) == FAILURE ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, &z);

	ret	= php_stream_seek(stream, offset, whence);

	RETURN_LONG(ret);
}

PHP_FUNCTION(sample0_frewind)
{
	zval		*z;
	php_stream	*stream;
	int			ret;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &z) == FAILURE ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, &z);

	ret	= php_stream_rewind(stream);

	RETURN_LONG(ret);
}

PHP_FUNCTION(sample0_frewinddir)
{
	zval		*z;
	php_stream	*stream;
	int			ret;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &z) == FAILURE ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, &z);

	ret	= php_stream_rewinddir(stream);
	RETURN_LONG(ret);
}

PHP_FUNCTION(sample0_ftell)
{
	zval		*z;
	php_stream	*stream;
	int			offset;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &z) == FAILURE ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, &z);

	offset	= php_stream_tell(stream);

	RETURN_LONG(offset);
}

static void return_stat_as_array(php_stream_statbuf *stat, INTERNAL_FUNCTION_PARAMETERS)
{
	array_init(return_value);
	add_assoc_long(return_value, "ino", stat->sb.st_ino);
	add_assoc_long(return_value, "file_mode", stat->sb.st_mode);
	add_assoc_long(return_value, "link_count", stat->sb.st_nlink);
	add_assoc_long(return_value, "uid", stat->sb.st_uid);
	add_assoc_long(return_value, "gid", stat->sb.st_gid);
	add_assoc_long(return_value, "size", stat->sb.st_size);
	add_assoc_long(return_value, "block_size", stat->sb.st_blksize);
	add_assoc_long(return_value, "block_num", stat->sb.st_blocks);
	add_assoc_double(return_value, "atim", (stat->sb.st_atim.tv_sec * 1000000 + stat->sb.st_atim.tv_nsec) / 1000000.0);
	add_assoc_double(return_value, "mtim", (stat->sb.st_mtim.tv_sec * 1000000 + stat->sb.st_mtim.tv_nsec) / 1000000.0);
	add_assoc_double(return_value, "ctim", (stat->sb.st_ctim.tv_sec * 1000000 + stat->sb.st_ctim.tv_nsec) / 1000000.0);
	add_assoc_long(return_value, "atime", stat->sb.st_atime);
	add_assoc_long(return_value, "mtime", stat->sb.st_mtime);
	add_assoc_long(return_value, "ctime", stat->sb.st_ctime);
}

PHP_FUNCTION(sample0_fstat)
{
	zval				*z;
	php_stream			*stream;
	php_stream_statbuf	stat;
	int					ret;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &z) == FAILURE ) {
		RETURN_FALSE;
	}

	php_stream_from_zval(stream, &z);

	ret	= php_stream_stat(stream, &stat);

	if ( ret != 0 ) {
		RETURN_FALSE;
	}

	return_stat_as_array(&stat, INTERNAL_FUNCTION_PARAM_PASSTHRU);
}

PHP_FUNCTION(sample0_stat_path)
{
	char				*path;
	php_stream_statbuf	stat;
	int					path_len, ret;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &path, &path_len) == FAILURE ) {
		RETURN_FALSE;
	}

	ret	= php_stream_stat_path(path, &stat);

	if ( ret != 0 ) {
		RETURN_FALSE;
	}

	return_stat_as_array(&stat, INTERNAL_FUNCTION_PARAM_PASSTHRU);
}
