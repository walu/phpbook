<?php
$fp	= fopen('php://stderr', 'w+');
stream_filter_append($fp, "sample.rot13");
fwrite($fp, "helloWORLD");
