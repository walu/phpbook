<?php
$fp	= sample0_fsockopen("tcp://www.baidu.com:80");
fwrite($fp, "GET / HTTP/1.1\r\nHost: www.baidu.com\r\n\r\n");
while ( $resp = fread($fp, 1024) ) 
	echo $resp;
