<?php
$fp0		= sample_fopen('/tmp/a', 'a', TRUE);
$fp1		= sample_fopen('/tmp/a', 'a', TRUE);

sample_fwrite($fp0, "HELLO\n");
sample_fwrite($fp1, "WORLD\n");

echo sample_fname($fp0) . chr(10);
echo sample_fname($fp1) . chr(10);

sample_fclose($fp0);
sample_fclose($fp1);

echo '-------------------------------' . chr(10);
$a0	= sample_fopen("/tmp/b", 'a', FALSE);
$a1	= &$a0;
$a2	= $a0;

debug_zval_dump($a0);
debug_zval_dump($a1);
debug_zval_dump($a2);
sample_frsrc_info($a0);
sample_frsrc_info($a1);
sample_frsrc_info($a2);
unset($a0);
sample_frsrc_info($a1);

$b0	= sample_fopen("/tmp/b", 'a', TRUE);
$b1	= $b0;
$b2	=& $b0;
