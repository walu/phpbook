/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2012 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

/* $Id$ */
#include <stdio.h>

#ifndef PHP_SAMPLE_H
#define PHP_SAMPLE_H

ZEND_BEGIN_MODULE_GLOBALS(sample)
	unsigned long	counter;
	char			*greeting;
	long			long_value;
	double			double_value;
	zend_bool		bool_value;
ZEND_END_MODULE_GLOBALS(sample)

extern zend_module_entry sample_module_entry;
#define phpext_sample_ptr &sample_module_entry

#ifdef PHP_WIN32
#	define PHP_SAMPLE_API __declspec(dllexport)
#elif defined(__GNUC__) && __GNUC__ >= 4
#	define PHP_SAMPLE_API __attribute__ ((visibility("default")))
#else
#	define PHP_SAMPLE_API
#endif

#ifdef ZTS
#include "TSRM.h"
#endif

typedef struct sample_descriptor_data_s	sample_descriptor_data_t;
struct sample_descriptor_data_s {
	char	*fname;
	FILE	*fp;
};

PHP_MINIT_FUNCTION(sample);
PHP_MSHUTDOWN_FUNCTION(sample);
PHP_RINIT_FUNCTION(sample);
PHP_RSHUTDOWN_FUNCTION(sample);
PHP_MINFO_FUNCTION(sample);

PHP_FUNCTION(sample_long);
PHP_FUNCTION(sample_array_range);
#if (PHP_MAJOR_VERSION > 5) || (PHP_MAJOR_VERSION == 5 && PHP_MINOR_VERSION > 0 )
ZEND_BEGIN_ARG_INFO_EX(sample_reference_a_arginfo, 0, ZEND_RETURN_REFERENCE, 0)
ZEND_END_ARG_INFO()
PHP_FUNCTION(sample_reference_a);
#endif
#ifdef ZEND_ENGINE_2
ZEND_BEGIN_ARG_INFO(sample_byref_compile_arginfo, 0)
	ZEND_ARG_PASS_INFO(1)
ZEND_END_ARG_INFO()
#else	/* ZEND_ENGINE_1 */
static unsigned char	sample_byref_compile_arginfo[]	= 
	{1, BYREF_FORCE};
#endif
PHP_FUNCTION(sample_byref_compile);
PHP_FUNCTION(sample_hello_world);
PHP_FUNCTION(sample_ht);
#ifdef ZEND_ENGINE_2
ZEND_BEGIN_ARG_INFO(sample_array_copy_arginfo, 0)
	ZEND_ARG_ARRAY_INFO(1, "a", 0)
	ZEND_ARG_ARRAY_INFO(1, "b", 0)
	ZEND_ARG_PASS_INFO(0)
ZEND_END_ARG_INFO()
#else
static unsigned char	sample_array_copy_arginfo[]	= 
	{3, BYREF_FORCE, BYREF_FORCE, 0};
#endif
PHP_FUNCTION(sample_array_copy);
PHP_FUNCTION(sample_array_copy_assoc_only);
PHP_FUNCTION(sample_array_iterate_print);
PHP_FUNCTION(sample_array_iterate_print_key);
PHP_FUNCTION(sample_array_iterate_move_forward);
PHP_FUNCTION(sample_funcname_sort);
PHP_FUNCTION(sample_array);
PHP_FUNCTION(sample_fopen);
PHP_FUNCTION(sample_fwrite);
PHP_FUNCTION(sample_fclose);
PHP_FUNCTION(sample_fname);
PHP_FUNCTION(sample_frsrc_info);
PHP_FUNCTION(sample_new);
PHP_FUNCTION(sample_getclassname);
PHP_FUNCTION(sample_classhint);
PHP_FUNCTION(sample_counter);
PHP_FUNCTION(sample_greeting);


PHP_FUNCTION(SampleFirstClass_method1);
PHP_METHOD(SampleFirstClass, sayHello);
PHP_FUNCTION(sample_firstclass_ctor);
PHP_METHOD(SampleSecondClass, __construct);

#define SAMPLE_DESCRIPTOR_RES_NAME	"File Descriptor"

/* In every utility function you add that needs to use variables 
   in php_sample_globals, call TSRMLS_FETCH(); after declaring other 
   variables used by that function, or better yet, pass in TSRMLS_CC
   after the last function argument and declare your utility function
   with TSRMLS_DC after the last declared argument.  Always refer to
   the globals in your function as SAMPLE_G(variable).  You are 
   encouraged to rename these macros something shorter, see
   examples in any other php module directory.
*/

#ifdef ZTS
#define SAMPLE_G(v) TSRMG(sample_globals_id, zend_sample_globals *, v)
#else
#define SAMPLE_G(v) (sample_globals.v)
#endif

#endif	/* PHP_SAMPLE_H */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
