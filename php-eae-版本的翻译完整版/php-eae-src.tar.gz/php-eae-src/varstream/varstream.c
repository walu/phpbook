/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2012 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

/* $Id$ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "ext/standard/url.h"
#include "ext/standard/file.h"
#include "ext/standard/php_string.h"
#include "php_varstream.h"

typedef struct {
	char	is_persistent;
	char	*tr_from;
	char	*tr_to;
	int		tr_len;
} php_sample6_filter_data;

/* 过滤逻辑 */
static php_stream_filter_status_t php_sample6_filter(
		php_stream *stream, php_stream_filter *thisfilter, 
		php_stream_bucket_brigade *buckets_in, 
		php_stream_bucket_brigade *buckets_out, 
		size_t *bytes_consumed, int flags TSRMLS_DC) 
{
	php_stream_bucket		*bucket;
	php_sample6_filter_data	*data		= thisfilter->abstract;
	size_t					consumed	= 0;

	while ( buckets_in->head ) {
		bucket		= php_stream_bucket_make_writeable(buckets_in->head TSRMLS_CC);
		php_strtr(bucket->buf, bucket->buflen, data->tr_from, data->tr_to, data->tr_len);
		consumed	+= bucket->buflen;
		php_stream_bucket_append(buckets_out, bucket TSRMLS_CC);
	}
	if ( bytes_consumed ) {
		*bytes_consumed	= consumed;
	}
	return PSFS_PASS_ON;
}

/* 过滤器的释放 */
static void php_sample6_filter_dtor(php_stream_filter *thisfilter TSRMLS_DC)
{
	php_sample6_filter_data	*data	= thisfilter->abstract;
	pefree(data, data->is_persistent);
}

/* 流过滤器操作表 */
static php_stream_filter_ops php_sample6_filter_ops = {
	php_sample6_filter, 
	php_sample6_filter_dtor, 
	"sample.*",
};

/* 字符翻译使用的表 */
#define PHP_SAMPLE6_ALPHA_UCASE		"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
#define PHP_SAMPLE6_ALPHA_LCASE		"abcdefghijklmnopqrstuvwxyz"
#define PHP_SAMPLE6_ROT13_UCASE		"NOPQRSTUVWXYZABCDEFGHIJKLM"
#define PHP_SAMPLE6_ROT13_LCASE		"nopqrstuvwxyzabcdefghijklm"

/* 创建流过滤器实例的过程 */
static php_stream_filter *php_sample6_filter_create(
		const char *name, zval *param, int persistent TSRMLS_DC)
{
	php_sample6_filter_data	*data;
	char					*subname;

	/* 安全性检查 */
	if ( strlen(name) < sizeof("sample.") || strncmp(name, "sample.", sizeof("sample.") - 1) ) {
		return NULL;
	}

	/* 分配流过滤器数据 */
	data	= pemalloc(sizeof(php_sample6_filter_data), persistent);

	if ( !data ) {
		return NULL;
	}

	/* 设置持久性 */
	data->is_persistent	= persistent;

	/* 根据调用时的名字, 对过滤器数据进行适当初始化 */
	subname	= (char *)name + sizeof("sample.") - 1;
	if ( strcmp(subname, "ucase") == 0 ) {
		data->tr_from	= PHP_SAMPLE6_ALPHA_LCASE;
		data->tr_to		= PHP_SAMPLE6_ALPHA_UCASE;
	} else if ( strcmp(subname, "lcase") == 0 ) {
		data->tr_from	= PHP_SAMPLE6_ALPHA_UCASE;
		data->tr_to		= PHP_SAMPLE6_ALPHA_LCASE;
	} else if ( strcmp(subname, "rot13") == 0 ) {
		data->tr_from	= PHP_SAMPLE6_ALPHA_LCASE
						PHP_SAMPLE6_ALPHA_UCASE;;
		data->tr_to		= PHP_SAMPLE6_ROT13_LCASE
						PHP_SAMPLE6_ROT13_UCASE;
	} else {
		/* 不支持 */
		pefree(data, persistent);
		return NULL;
	}

	/* 节省未来使用时每次的计算 */
	data->tr_len	= strlen(data->tr_from);

	/* 分配一个php_stream_filter结构并按指定参数初始化 */
	return php_stream_filter_alloc(&php_sample6_filter_ops, data, persistent);
}

/* 流过滤器工厂, 用于创建流过滤器实例(php_stream_filter_append/prepend的时候) */
static php_stream_filter_factory php_sample6_samples_factory = {
	php_sample6_filter_create
};

static size_t php_varstream_write(php_stream *stream,
                const char *buf, size_t count TSRMLS_DC)
{
    php_varstream_data *data = stream->abstract;
    zval **var;
    size_t newlen;

	/* 查找变量 */
    if (zend_hash_find(&EG(symbol_table), data->varname,
            data->varname_len + 1,(void**)&var) == FAILURE) {
		/* 变量不存在, 直接创建一个字符串类型的变量, 并保存新传递进来的内容 */
       zval *newval;
       MAKE_STD_ZVAL(newval);
       ZVAL_STRINGL(newval, buf, count, 1);
	   /* 将新的zval *放到变量中 */
       zend_hash_add(&EG(symbol_table), data->varname,
           data->varname_len + 1, (void*)&newval,
           sizeof(zval*), NULL);
       return count;
    }
	/* 如果需要, 让变量可写. 这里实际上处理的是写时复制 */
    SEPARATE_ZVAL_IF_NOT_REF(var);
	/* 转换为字符串类型 */
    convert_to_string_ex(var);
	/* 重置偏移量(译注: 相比于正常的文件系统, 这里的处理实际上不支持文件末尾的空洞创建, 读者如果熟悉*nix文件系统, 应该了解译者所说, 否则请略过) */
    if (data->position > Z_STRLEN_PP(var)) {
        data->position = Z_STRLEN_PP(var);
    }
	/* 计算新的字符串长度 */
    newlen = data->position + count;
    if (newlen < Z_STRLEN_PP(var)) {
		/* 总长度不变 */
        newlen = Z_STRLEN_PP(var);
    } else if (newlen > Z_STRLEN_PP(var)) {
		/* 重新调整缓冲区大小以保存新内容 */
        Z_STRVAL_PP(var) =erealloc(Z_STRVAL_PP(var),newlen+1);
		/* 更新字符串长度 */
        Z_STRLEN_PP(var) = newlen;
		/* 确保字符串NULL终止 */
        Z_STRVAL_PP(var)[newlen] = 0;
    }
	/* 将数据写入到变量中 */
    memcpy(Z_STRVAL_PP(var) + data->position, buf, count);
    data->position += count;

    return count;
}

static size_t php_varstream_read(php_stream *stream,
                char *buf, size_t count TSRMLS_DC)
{
    php_varstream_data *data = stream->abstract;
    zval **var, copyval;
    int got_copied = 0;
    size_t toread = count;

    if (zend_hash_find(&EG(symbol_table), data->varname,
        data->varname_len + 1, (void**)&var) == FAILURE) {
		/* 变量不存在, 读不到数据, 返回0字节长度 */
        return 0;
    }
    copyval = **var;
    if (Z_TYPE(copyval) != IS_STRING) {
		/* 对于非字符串类型变量, 创建一个副本进行读, 这样对于只读的变量, 就不会改变其原始类型 */
        zval_copy_ctor(&copyval);
        INIT_PZVAL(&copyval);
        got_copied = 1;
    }
    if (data->position > Z_STRLEN(copyval)) {
        data->position = Z_STRLEN(copyval);
    }
    if ((Z_STRLEN(copyval) - data->position) < toread) {
		/* 防止读取到变量可用缓冲区外的内容 */
        toread = Z_STRLEN(copyval) - data->position;
    }
	/* 设置缓冲区 */
    memcpy(buf, Z_STRVAL(copyval) + data->position, toread);
    data->position += toread;

	/* 如果创建了副本, 则释放副本 */
    if (got_copied) {
        zval_dtor(&copyval);
    }

	/* 返回设置到缓冲区的字节数 */
    return toread;
}

static int php_varstream_closer(php_stream *stream,
                            int close_handle TSRMLS_DC)
{
    php_varstream_data *data = stream->abstract;

	/* 释放内部结构避免泄露 */
    efree(data->varname);
    efree(data);

    return 0;
}

static int php_varstream_flush(php_stream *stream TSRMLS_DC)
{
    php_varstream_data *data = stream->abstract;
    zval **var;

	/* 根据不同情况, 重置偏移量 */
    if (zend_hash_find(&EG(symbol_table), data->varname,
                    data->varname_len + 1, (void**)&var)
                    == SUCCESS) {
        if (Z_TYPE_PP(var) == IS_STRING) {
            data->position = Z_STRLEN_PP(var);
        } else {
            zval copyval = **var;
            zval_copy_ctor(&copyval);
            convert_to_string(&copyval);
            data->position = Z_STRLEN(copyval);
            zval_dtor(&copyval);
        }
    } else {
        data->position = 0;
    }

    return 0;
}

static int php_varstream_seek(php_stream *stream, off_t offset,
                    int whence, off_t *newoffset TSRMLS_DC)
{
    php_varstream_data *data = stream->abstract;

    switch (whence) {
        case SEEK_SET:
            data->position = offset;
            break;
        case SEEK_CUR:
            data->position += offset;
            break;
        case SEEK_END:
        {
            zval **var;
           size_t curlen = 0;

           if (zend_hash_find(&EG(symbol_table),
                   data->varname,    data->varname_len + 1,
                   (void**)&var) == SUCCESS) {
              if (Z_TYPE_PP(var) == IS_STRING) {
                  curlen = Z_STRLEN_PP(var);
              } else {
                  zval copyval = **var;
                  zval_copy_ctor(&copyval);
                  convert_to_string(&copyval);
                  curlen = Z_STRLEN(copyval);
                  zval_dtor(&copyval);
              }
           }

           data->position = curlen + offset;
           break;
       }
    }

	/* 防止随机访问指针移动到缓冲区开始位置之前 */
    if (data->position < 0) {
        data->position = 0;
    }

    if (newoffset) {
        *newoffset = data->position;
    }

    return 0;
}

static php_stream_ops php_varstream_ops = {
    php_varstream_write,
    php_varstream_read,
    php_varstream_closer,
    php_varstream_flush,
    PHP_VARSTREAM_STREAMTYPE,
    php_varstream_seek,
    NULL, /* cast */
    NULL, /* stat */
    NULL, /* set_option */
};

/* Define the wrapper operations */
static php_stream *php_varstream_opener(
            php_stream_wrapper *wrapper,
            char *filename, char *mode, int options,
            char **opened_path, php_stream_context *context
            STREAMS_DC TSRMLS_DC)
{
    php_varstream_data *data;
    php_url *url;

    if (options & STREAM_OPEN_PERSISTENT) {
		/* 按照变量流的定义, 是不能持久化的
		 * 因为变量在请求结束后将被释放
		 */
        php_stream_wrapper_log_error(wrapper, options
            TSRMLS_CC, "Unable to open %s persistently",
                                        filename);
        return NULL;
    }

	/* 标准URL解析: scheme://user:pass@host:port/path?query#fragment */
    url = php_url_parse(filename);
    if (!url) {
        php_stream_wrapper_log_error(wrapper, options
            TSRMLS_CC, "Unexpected error parsing URL");
        return NULL;
    }
	/* 检查是否有变量流URL必须的元素host, 以及scheme是否是var */
    if (!url->host || (url->host[0] == 0) ||
        strcasecmp("var", url->scheme) != 0) {
        /* Bad URL or wrong wrapper */
        php_stream_wrapper_log_error(wrapper, options
            TSRMLS_CC, "Invalid URL, must be in the form: "
                     "var://variablename");
        php_url_free(url);
        return NULL;
    }

	/* 创建一个数据结构保存协议信息(变量流协议重要是变量名, 变量名长度, 当前偏移量) */
    data = emalloc(sizeof(php_varstream_data));
    data->position = 0;
    data->varname_len = strlen(url->host);
    data->varname = estrndup(url->host, data->varname_len + 1);
	/* 释放前面解析出来的url占用的内存 */
    php_url_free(url);

	/* 实例化一个流, 为其赋予恰当的流ops, 绑定抽象数据 */
    return php_stream_alloc(&php_varstream_ops, data, 0, mode);
}

static size_t php_varstream_readdir(php_stream *stream,
                char *buf, size_t count TSRMLS_DC)
{
    php_stream_dirent *ent = (php_stream_dirent*)buf;
    php_varstream_dirdata *data = stream->abstract;
    char *key;
    int type, key_len;
    long idx;

	/* 查找数组中的key */
    type = zend_hash_get_current_key_ex(Z_ARRVAL_P(data->arr),
                    &key, &key_len, &idx, 0, &(data->pos));

	/* 字符串key */
    if (type == HASH_KEY_IS_STRING) {
        if (key_len >= sizeof(ent->d_name)) {
            /* truncate long keys to maximum length */
            key_len = sizeof(ent->d_name) - 1;
        }
		/* 设置到目录结构上 */
        memcpy(ent->d_name, key, key_len);
        ent->d_name[key_len] = 0;
	/* 数值key */
    } else if (type == HASH_KEY_IS_LONG) {
		/* 设置到目录结构上 */
        snprintf(ent->d_name, sizeof(ent->d_name), "%ld",idx);
    } else {
		/* 迭代结束 */
        return 0;
    }
	/* 移动数组指针(位置记录到流的抽象结构中) */
    zend_hash_move_forward_ex(Z_ARRVAL_P(data->arr),
                                        &data->pos);
    return sizeof(php_stream_dirent);
}

static int php_varstream_closedir(php_stream *stream,
                            int close_handle TSRMLS_DC)
{
    php_varstream_dirdata *data = stream->abstract;

    zval_ptr_dtor(&(data->arr));
    efree(data);
    return 0;
}

static int php_varstream_dirseek(php_stream *stream,
                    off_t offset, int whence,
                    off_t *newoffset TSRMLS_DC)
{
    php_varstream_dirdata *data = stream->abstract;

    if (whence == SEEK_SET && offset == 0) {
		/* 重置数组指针 */
        zend_hash_internal_pointer_reset_ex(
                    Z_ARRVAL_P(data->arr), &(data->pos));
        if (newoffset) {
            *newoffset = 0;
        }
        return 0;
    }
	/* 不支持其他类型的随机访问 */
    return -1;
}

static php_stream_ops php_varstream_dirops = {
    NULL, /* write */
    php_varstream_readdir,
    php_varstream_closedir,
    NULL, /* flush */
    PHP_VARSTREAM_DIRSTREAMTYPE,
    php_varstream_dirseek,
    NULL, /* cast */
    NULL, /* stat */
    NULL, /* set_option */
};

static php_stream *php_varstream_opendir(
            php_stream_wrapper *wrapper,
            char *filename, char *mode, int options,
            char **opened_path, php_stream_context *context
            STREAMS_DC TSRMLS_DC)
{
	php_varstream_dirdata *data;
	php_url *url;
	zval **var;

	/* 不支持持久化流 */
	if (options & STREAM_OPEN_PERSISTENT) {
		php_stream_wrapper_log_error(wrapper, options
				TSRMLS_CC, "Unable to open %s persistently",
				filename);
		return NULL;
	}

	/* 解析URL */
	url = php_url_parse(filename);
	if (!url) {
		php_stream_wrapper_log_error(wrapper, options
				TSRMLS_CC, "Unexpected error parsing URL");
		return NULL;
	}
	/* 检查请求URL的正确性 */
	if (!url->host || (url->host[0] == 0) ||
			strcasecmp("var", url->scheme) != 0) {
		/* Bad URL or wrong wrapper */
		php_stream_wrapper_log_error(wrapper, options
				TSRMLS_CC, "Invalid URL, must be in the form: "
				"var://variablename");
		php_url_free(url);
		return NULL;
	}

	/* 查找变量 */
	if (zend_hash_find(&EG(symbol_table), url->host,
				strlen(url->host) + 1, (void**)&var) == FAILURE) {
		php_stream_wrapper_log_error(wrapper, options
				TSRMLS_CC, "Variable $%s not found", url->host);
		php_url_free(url);
		return NULL;
	}

	/* 检查变量类型 */
	if (Z_TYPE_PP(var) != IS_ARRAY) {
		php_stream_wrapper_log_error(wrapper, options
				TSRMLS_CC, "$%s is not an array", url->host);
		php_url_free(url);
		return NULL;
	}
	/* 释放前面分配的URL结构 */
	php_url_free(url);

	/* 分配抽象数据结构 */
	data = emalloc(sizeof(php_varstream_dirdata));
	if ( Z_ISREF_PP(var) && Z_REFCOUNT_PP(var) > 1) {
		/* 全拷贝 */
		MAKE_STD_ZVAL(data->arr);
		*(data->arr) = **var;
		zval_copy_ctor(data->arr);
		INIT_PZVAL(data->arr);
	} else {
		/* 写时拷贝 */
		data->arr = *var;
		Z_SET_REFCOUNT_P(data->arr, Z_REFCOUNT_P(data->arr) + 1);
	}
	/* 重置数组指针 */
	zend_hash_internal_pointer_reset_ex(Z_ARRVAL_P(data->arr),
			&data->pos);
	return php_stream_alloc(&php_varstream_dirops,data,0,mode);
}

static int php_varstream_unlink(php_stream_wrapper *wrapper,
                        char *filename, int options,
                        php_stream_context *context
                        TSRMLS_DC)
{
    php_url *url;

    url = php_url_parse(filename);
    if (!url) {
        php_stream_wrapper_log_error(wrapper, options
            TSRMLS_CC, "Unexpected error parsing URL");
        return -1;
    }
    if (!url->host || (url->host[0] == 0) ||
        strcasecmp("var", url->scheme) != 0) {
		/* URL不合法 */
        php_stream_wrapper_log_error(wrapper, options
            TSRMLS_CC, "Invalid URL, must be in the form: "
                     "var://variablename");
        php_url_free(url);
        return -1;
    }

    /* 从符号表删除变量 */
    //zend_hash_del(&EG(symbol_table), url->host, strlen(url->host) + 1);
	zend_delete_global_variable(url->host, strlen(url->host) + 1 TSRMLS_CC);

    php_url_free(url);
    return 0;
}

static int php_varstream_rename(php_stream_wrapper *wrapper,
        char *url_from, char *url_to, int options,
        php_stream_context *context TSRMLS_DC)
{
    php_url *from, *to;
    zval **var;

	/* 来源URL解析 */
    from = php_url_parse(url_from);
    if (!from) {
        php_stream_wrapper_log_error(wrapper, options
            TSRMLS_CC, "Unexpected error parsing source");
        return -1;
    }
	/* 查找变量 */
    if (zend_hash_find(&EG(symbol_table), from->host,
                strlen(from->host) + 1,
                (void**)&var) == FAILURE) {
        php_stream_wrapper_log_error(wrapper, options
            TSRMLS_CC, "$%s does not exist", from->host);
        php_url_free(from);
        return -1;
    }
	/* 目标URL解析 */
    to = php_url_parse(url_to);
    if (!to) {
        php_stream_wrapper_log_error(wrapper, options
            TSRMLS_CC, "Unexpected error parsing dest");
        php_url_free(from);
        return -1;
    }
	/* 变量的改名 */
	Z_SET_REFCOUNT_PP(var, Z_REFCOUNT_PP(var) + 1);
    zend_hash_update(&EG(symbol_table), to->host,
                strlen(to->host) + 1, (void*)var,
                sizeof(zval*), NULL);
    zend_hash_del(&EG(symbol_table), from->host,
                strlen(from->host) + 1);
    php_url_free(from);
    php_url_free(to);
    return 0;
}

static int php_varstream_mkdir(php_stream_wrapper *wrapper,
                char *url_from, int mode, int options,
                php_stream_context *context TSRMLS_DC)
{
    php_url *url;

	/* URL解析 */
    url	= php_url_parse(url_from);
    if (!url) {
       php_stream_wrapper_log_error(wrapper, options
           TSRMLS_CC, "Unexpected error parsing URL");
       return -1;
    }

	/* 检查变量是否存在 */
    if (zend_hash_exists(&EG(symbol_table), url->host,
                    strlen(url->host) + 1)) {
        php_stream_wrapper_log_error(wrapper, options
            TSRMLS_CC, "$%s already exists", url->host);
        php_url_free(url);
        return -1;
    }
	/* EG(uninitialized_zval_ptr)通常是IS_NULL的zval *, 引用计数无限大 */
    zend_hash_add(&EG(symbol_table), url->host,
            strlen(url->host) + 1,
            (void*)&EG(uninitialized_zval_ptr),
            sizeof(zval*), NULL);
    php_url_free(url);
    return 0;
}

static int php_varstream_rmdir(php_stream_wrapper *wrapper,
                char *url, int options,
                php_stream_context *context TSRMLS_DC)
{
	/* 行为等价于unlink() */
    wrapper->wops->unlink(wrapper, url, options,
                                context TSRMLS_CC);
}

static php_stream_wrapper_ops php_varstream_wrapper_ops = {
    php_varstream_opener, /* 调用php_stream_open_wrapper(sprintf("%s://xxx", PHP_VARSTREAM_WRAPPER))时执行 */
    NULL, /* stream_close */
    NULL, /* stream_stat */
    NULL, /* url_stat */
    php_varstream_opendir, /* dir_opener */
    PHP_VARSTREAM_WRAPPER,
    php_varstream_unlink, /* unlink */
#if PHP_MAJOR_VERSION >= 5
    /* PHP >= 5.0 only */
    php_varstream_rename, /* rename */
    php_varstream_mkdir, /* mkdir */
    php_varstream_rmdir, /* rmdir */
#endif
};

static php_stream_wrapper php_varstream_wrapper = {
    &php_varstream_wrapper_ops,
    NULL, /* abstract */
    0, /* is_url */
};


PHP_MINIT_FUNCTION(varstream)
{
	/* 注册流包装器:
	 * 1. 检查流包装器名字是否正确(符合这个正则: /^[a-zA-Z0-9+.-]+$/)
	 * 2. 将传入的php_varstream_wrapper增加到url_stream_wrappers_hash这个HashTable中, key为PHP_VARSTREAM_WRAPPER
	 */
    if (php_register_url_stream_wrapper(PHP_VARSTREAM_WRAPPER,
            &php_varstream_wrapper TSRMLS_CC)==FAILURE) {
        return FAILURE;
    }

	php_stream_filter_register_factory("sample.*", &php_sample6_samples_factory TSRMLS_CC);
    return SUCCESS;
}

PHP_MSHUTDOWN_FUNCTION(varstream)
{
	/* 卸载流包装器: 从url_stream_wrappers_hash中删除 */
    if (php_unregister_url_stream_wrapper(PHP_VARSTREAM_WRAPPER
                                TSRMLS_CC) == FAILURE) {
        return FAILURE;
    }

	php_stream_filter_unregister_factory("sample.*" TSRMLS_CC);
    return SUCCESS;
}

php_stream	*php_varstream_get_homepage(const char *alt_user_agent TSRMLS_DC)
{
	php_stream_context	*context;
	zval	tmpval;

	context	= php_stream_context_alloc(TSRMLS_C);
	ZVAL_STRING(&tmpval, alt_user_agent, 0);
	php_stream_context_set_option(context, "http", "user_agent", &tmpval);
	return php_stream_open_wrapper_ex("http://www.php.net", "rb", REPORT_ERRORS | ENFORCE_SAFE_MODE, NULL, context);
}

PHP_FUNCTION(varstream_get_homepage)
{
	php_stream	*stream;
	char		*user_agent;
	int			user_agent_len;
	char		buffer[1024];
	int			n_read;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &user_agent, &user_agent_len) == FAILURE ) {
		RETURN_FALSE;
	}
	stream	= php_varstream_get_homepage(user_agent TSRMLS_CC);

	n_read	= php_stream_read(stream, buffer, 1024);

	php_stream_close(stream);

	RETURN_STRINGL(buffer, n_read, 1);
}

php_stream *php_varstream_fopen_read_ucase(const char *path TSRMLS_DC){
	php_stream_filter	*filter;
	php_stream			*stream;

	stream	= php_stream_open_wrapper_ex((char *)path, "r", REPORT_ERRORS | ENFORCE_SAFE_MODE, NULL, FG(default_context));

	if ( !stream ) {
		return NULL;
	}

	filter	= php_stream_filter_create("string.toupper", NULL, 0 TSRMLS_CC);

	if ( !filter ) {
		php_stream_close(stream);
		return NULL;
	}

	php_stream_filter_append(&stream->readfilters, filter);

	return stream;
}

PHP_FUNCTION(varstream_ucase_fopen)
{
	char		*path;
	int			path_len;
	php_stream	*stream;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &path, &path_len) == FAILURE ) {
		RETURN_FALSE;
	}

	stream	= php_varstream_fopen_read_ucase(path TSRMLS_CC);

	php_stream_to_zval(stream, return_value);
}

const zend_function_entry	varstream_functions[]	= {
	PHP_FE(varstream_get_homepage,			NULL)
	PHP_FE(varstream_ucase_fopen,			NULL)
	PHP_FE_END
};

zend_module_entry varstream_module_entry = {
#if ZEND_MODULE_API_NO >= 20010901
	STANDARD_MODULE_HEADER,
#endif
	"varstream",
	varstream_functions,
	PHP_MINIT(varstream),
	PHP_MSHUTDOWN(varstream),
	NULL,
	NULL,
	NULL,
#if ZEND_MODULE_API_NO >= 20010901
	"0.1",
#endif
	STANDARD_MODULE_PROPERTIES
};

#ifdef COMPILE_DL_VARSTREAM
ZEND_GET_MODULE(varstream)
#endif
