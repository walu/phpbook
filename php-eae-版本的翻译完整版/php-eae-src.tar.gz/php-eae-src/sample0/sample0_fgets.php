<?php
$fp	= sample0_fopen('/tmp/a', 'r');

while ( $line = sample0_fgetrecord($fp) )
	var_dump($line);
