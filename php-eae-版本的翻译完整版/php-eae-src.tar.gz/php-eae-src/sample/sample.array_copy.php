<?php
$a	= array("a" => 1, "b" => 2);
$b	= array();
sample_array_copy($a, $b, "a");
debug_zval_dump($a);
debug_zval_dump($b);
$a['a']	= 3;
debug_zval_dump($a);
debug_zval_dump($b);
