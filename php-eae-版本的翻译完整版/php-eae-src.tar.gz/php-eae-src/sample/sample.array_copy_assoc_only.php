<?php
$a	= array(1, 2, 3, 'a' => 4, 'b', 'c' => 5, 'd' => 6, 7, 8);
$b	= array();
sample_array_copy_assoc_only($a, $b);
print_r($b);
