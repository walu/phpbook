<?php
$fp	= sample0_fopen('/tmp/a', 'a');

$i	= 0;
while ( $i ++ < 10 ) {
	$n	= sample0_fprintf($fp, "HELLO");
	printf("times %d, writed %d\n", $i, $n);
}
