<?php
$fp	= sample0_fopen('/tmp/a', 'w');

sample0_fwrite($fp, "HELLO");
sample0_fseek($fp, 10, SEEK_CUR);
sample0_fwrite($fp, "WORLD!");
sample0_frewind($fp);
sample0_fwrite($fp, "hello");

printf("/tmp/a file offset: %d\n", sample0_ftell($fp));

$dp	= opendir('/tmp');
echo sample0_readdir($dp) . chr(10);
echo sample0_readdir($dp) . chr(10);
echo sample0_readdir($dp) . chr(10);
sample0_frewinddir($dp);
echo sample0_readdir($dp) . chr(10);
echo sample0_readdir($dp) . chr(10);
echo sample0_readdir($dp) . chr(10);

$info	= sample0_fstat($fp);
print_r($info);
$info1	= sample0_stat_path('/tmp/a');
print_r($info1);
