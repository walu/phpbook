#include <stdio.h>
#include <sapi/embed/php_embed.h>

int main(int argc, char *argv[]) {
	zend_file_handle	script;

	/* 基本的参数检查 */
	if ( argc <= 1 ) {
		fprintf(stderr, "Usage: %s <filename.php> <arguments>\n", argv[0]);
		return -1;
	}

	/* 设置一个文件处理结构 */
	script.type				= ZEND_HANDLE_FP;
	script.filename			= argv[1];
	script.opened_path		= NULL;
	script.free_filename	= 0;
	if ( !(script.handle.fp = fopen(script.filename, "rb")) ) {
		fprintf(stderr, "Unable to open: %s\n", argv[1]);
		return -1;
	}

	/* 在将命令行参数注册给php时(php中的$argv/$argc), 忽略第一个命令行参数, 因为它对php脚本无意义 */
	argc --;
	argv ++;

	PHP_EMBED_START_BLOCK(argc, argv)
		zval	**SERVER_PP, *type, *EMBED, *foo;

		/* 在全局作用域创建$_EMBED数组 */
		ALLOC_INIT_ZVAL(EMBED);
		array_init(EMBED);
		ZEND_SET_SYMBOL(&EG(symbol_table), "_EMBED", EMBED);

		/* $_EMBED['foo'] = 'Bar'; */
		ALLOC_INIT_ZVAL(foo);
		ZVAL_STRING(foo, "Bar", 1);
		add_assoc_zval_ex(EMBED, "foo", sizeof("foo"), foo);

		/* 注册超级全局变量$_EMBED */
		zend_register_auto_global("_EMBED", sizeof("_EMBED")
#ifdef ZEND_ENGINE_2
			, 1, NULL TSRMLS_CC);
#else
			, 1 TSRMLS_CC);
#endif

		/* 不论php.ini中如何设置都强制开启safe_mode */
		zend_alter_ini_entry("safe_mode", sizeof("safe_mode"), "1", sizeof("1") - 1, PHP_INI_ALL, PHP_INI_STAGE_RUNTIME);

		/* 注册$_SERVER超级全局变量 */
		zend_is_auto_global_quick("_SERVER", sizeof("_SERVER") - 1, 0 TSRMLS_CC);
		/* 查找$_SERVER超级全局变量 */
		zend_hash_find(&EG(symbol_table), "_SERVER", sizeof("_SERVER"), (void **)&SERVER_PP) ;

		/* $_SERVER['SAPI_TYPE'] = "Embedded"; */
		ALLOC_INIT_ZVAL(type);
		ZVAL_STRING(type, "Embedded", 1);
		ZEND_SET_SYMBOL(Z_ARRVAL_PP(SERVER_PP), "SAPI_TYPE", type);

		php_execute_script(&script TSRMLS_CC);
	PHP_EMBED_END_BLOCK()

	return 0;
}
