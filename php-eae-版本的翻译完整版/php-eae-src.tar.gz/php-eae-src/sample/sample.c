/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2012 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

/* $Id$ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_sample.h"
#include "main/SAPI.h"

ZEND_DECLARE_MODULE_GLOBALS(sample)

/* True global resources - no need for thread safety here */
static int 					le_sample_descriptor;
static int 					le_sample_descriptor_persist;
static zend_class_entry		*sample_first_class_entry;
static zend_class_entry		*sample_first_interface_entry;
static zend_class_entry		*sample_second_class_entry;

/* {{{ sample_functions[]
 *
 * Every user visible function must have an entry in sample_functions[].
 */
const zend_function_entry sample_functions[] = {
	PHP_FE(sample_long,	NULL)
	PHP_FE(sample_array_range, NULL)
#if (PHP_MAJOR_VERSION > 5) || (PHP_MAJOR_VERSION == 5 && PHP_MINOR_VERSION > 0 )
	PHP_FE(sample_reference_a, sample_reference_a_arginfo)
#endif
	PHP_FE(sample_byref_compile, sample_byref_compile_arginfo)
	PHP_FE(sample_hello_world, NULL)
	PHP_FE(sample_ht, NULL)
	PHP_FE(sample_array_copy, sample_array_copy_arginfo)
	PHP_FE(sample_array_copy_assoc_only, NULL) 
	PHP_FE(sample_array_iterate_print, NULL)
	PHP_FE(sample_array_iterate_print_key, NULL)
	PHP_FE(sample_array_iterate_move_forward, NULL)
	PHP_FE(sample_funcname_sort, NULL)
	PHP_FE(sample_array, NULL)
	PHP_FE(sample_fopen, NULL)
	PHP_FE(sample_fwrite, NULL)
	PHP_FE(sample_fclose, NULL)
	PHP_FE(sample_fname, NULL)
	PHP_FE(sample_frsrc_info, NULL)
	PHP_FE(sample_new, NULL)
	PHP_FE(sample_getclassname, NULL)
	PHP_FE(sample_classhint, NULL)
	PHP_FE(sample_counter, NULL)
	PHP_FE(sample_greeting, NULL)
	PHP_FE_END	/* Must be the last line in sample_functions[] */
};
/* }}} */

ZEND_INI_MH(sample_ini_greeting_onmodify)
{
	if ( new_value_length == 0 ) 
		return FAILURE;
	return SUCCESS;
}
ZEND_INI_DISP(sample_ini_greeting_disp)
{
	const char *value	= ini_entry->value;

	if ( type == ZEND_INI_DISPLAY_ORIG && ini_entry->modified ) {
		value	= ini_entry->orig_value;
	}
	if ( sapi_module.phpinfo_as_text ) {
		php_printf("%s", value);
	} else {
		php_printf("<b>%s</b>", value);
	}
}
PHP_INI_BEGIN()
	STD_PHP_INI_ENTRY_EX("sample.greeting", "Hello world", PHP_INI_ALL, OnUpdateStringUnempty, greeting, zend_sample_globals, sample_globals, sample_ini_greeting_disp)
	STD_PHP_INI_ENTRY("sample.long_value", "123", PHP_INI_ALL, OnUpdateLong, long_value, zend_sample_globals, sample_globals)
	STD_PHP_INI_ENTRY("sample.double_value", "1.23", PHP_INI_ALL, OnUpdateReal, double_value, zend_sample_globals, sample_globals)
	STD_PHP_INI_ENTRY("sample.bool_value", "on", PHP_INI_ALL, OnUpdateBool, bool_value, zend_sample_globals, sample_globals)
PHP_INI_END()

/* {{{ sample_module_entry
 */
zend_module_entry sample_module_entry = {
#if ZEND_MODULE_API_NO >= 20010901
	STANDARD_MODULE_HEADER,
#endif
	"sample",
	sample_functions,
	PHP_MINIT(sample),
	PHP_MSHUTDOWN(sample),
	PHP_RINIT(sample),		/* Replace with NULL if there's nothing to do at request start */
	PHP_RSHUTDOWN(sample),	/* Replace with NULL if there's nothing to do at request end */
	PHP_MINFO(sample),
#if ZEND_MODULE_API_NO >= 20010901
	"0.1", /* Replace with version number for your extension */
#endif
	STANDARD_MODULE_PROPERTIES
};
/* }}} */

#ifdef COMPILE_DL_SAMPLE
ZEND_GET_MODULE(sample)
#endif

static void sample_descriptor_dtor(zend_rsrc_list_entry *rsrc TSRMLS_DC)
{
	sample_descriptor_data_t	*sddp	= (sample_descriptor_data_t *)rsrc->ptr;
	fclose(sddp->fp);
	efree(sddp->fname);
	efree(sddp);
}
static void sample_descriptor_persist_dtor(zend_rsrc_list_entry *rsrc TSRMLS_DC)
{
	sample_descriptor_data_t	*sddp	= (sample_descriptor_data_t *)rsrc->ptr;
	fclose(sddp->fp);
	pefree(sddp->fname, 1);
	pefree(sddp, 1);
}
PHP_FUNCTION(SampleFirstClass_method1)
{
	RETURN_LONG(zend_hash_num_elements(Z_OBJPROP_P(getThis())));
}
PHP_METHOD(SampleFirstClass, sayHello)
{
	char	*name;
	int		name_len;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s", &name, &name_len) == FAILURE ) {
		RETURN_FALSE;
	}

	php_printf("Hello ");
	PHPWRITE(name, name_len);
	php_printf("! You called an object method!\n");
	RETURN_TRUE;
}
PHP_FUNCTION(sample_firstclass_ctor)
{
	zval	*o	= getThis();

	if ( !o ) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Constructor called statically!");
		RETURN_FALSE;
	}
	add_property_long(o, "life", 42);
	add_property_double(o, "pi", 3.1415926535);
}
static zend_function_entry	sample_first_interface_function_entries[]	= {
	PHP_ABSTRACT_ME(SampleFirstInterface, sayHi, NULL)
	PHP_ABSTRACT_ME(SampleFirstInterface, sayHello, NULL)
	PHP_FE_END
};
static zend_function_entry	sample_first_class_function_entries[]	= {
	PHP_NAMED_FE(method1, PHP_FN(SampleFirstClass_method1), NULL)
	PHP_ME(SampleFirstClass, sayHello, NULL, ZEND_ACC_PUBLIC)
	PHP_MALIAS(SampleFirstClass, sayHi, sayHello, NULL, ZEND_ACC_PUBLIC)
	PHP_NAMED_FE(SampleFirstClass, PHP_FN(sample_firstclass_ctor), NULL)
	PHP_FE_END
};
static zend_function_entry	sample_second_class_function_entries[]	= {
	PHP_ME(SampleSecondClass, __construct, NULL, ZEND_ACC_PUBLIC | ZEND_ACC_CTOR)
	PHP_FE_END
};
static zend_object_handlers	sample_second_class_object_handlers;
static zval *sample_second_class_handler_read_dimension(zval *object, zval *member, int type TSRMLS_DC) {
	return sample_second_class_object_handlers.read_property(object, member, type, NULL TSRMLS_CC);
}
static void sample_second_class_handler_write_dimension(zval *object, zval *member, zval *value TSRMLS_DC) {
	sample_second_class_object_handlers.write_property(object, member, value, NULL TSRMLS_CC);
}
static int sample_second_class_handler_has_dimension(zval *object, zval *offset, int check_empty TSRMLS_DC) {
	if ( check_empty == 0 ) 
		check_empty	= 2;
	return sample_second_class_object_handlers.has_property(object, offset, check_empty, NULL TSRMLS_CC);
}
static void sample_second_class_handler_unset_dimension(zval *object, zval *offset TSRMLS_DC) {
	sample_second_class_object_handlers.unset_property(object, offset, NULL TSRMLS_CC);
}
static int sample_first_class_register_constants(zend_class_entry *ce) {
	zval	*z;

	z	= pemalloc(sizeof(zval), 1);
	INIT_PZVAL(z);
	ZVAL_DOUBLE(z, 2.7182818284);
	zend_hash_add(&ce->constants_table, "E", sizeof("E"), (void *)&z, sizeof(zval *), NULL);

	z	= pemalloc(sizeof(zval), 1);
	INIT_PZVAL(z);
	Z_TYPE_P(z)		= IS_STRING;
	Z_STRLEN_P(z)	= sizeof("Hello") - 1;
	Z_STRVAL_P(z)	= pemalloc(Z_STRLEN_P(z) + 1, 1);
	memcpy(Z_STRVAL_P(z), "Hello", Z_STRLEN_P(z));
	zend_hash_add(&ce->constants_table, "GREETING", sizeof("GREETING"), (void *)&z, sizeof(zval *), NULL);

}
PHP_METHOD(SampleSecondClass, __construct)
{
	zval	*o	= getThis();

	if ( !o ) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Constructor called statically!");
		RETURN_FALSE;
	}
	Z_OBJ_HT_P(o)	= &sample_second_class_object_handlers;
#if ZEND_DEBUG
	printf("call the construct method\n");
#endif
}
static zend_object_value sample_second_class_sc_create(zend_class_entry *ce TSRMLS_DC)
{
	zend_object			*o;
	zend_object_value	r;

	r	= zend_objects_new(&o, ce TSRMLS_CC);
	ALLOC_HASHTABLE(o->properties);
	zend_hash_init(o->properties, 0, NULL, ZVAL_PTR_DTOR, 0);

	r.handlers	= &sample_second_class_object_handlers;
#if ZEND_DEBUG
	printf("call the overrided object create method\n");
#endif
	return r;
}
static int sample_register_first_class(INIT_FUNC_ARGS) {
	zend_class_entry		ce;
	zend_object_handlers	*h;

	INIT_CLASS_ENTRY(ce, "SampleFirstInterface", sample_first_interface_function_entries);
	sample_first_interface_entry			= zend_register_internal_class(&ce TSRMLS_CC);
	sample_first_interface_entry->ce_flags	|= ZEND_ACC_INTERFACE;

	INIT_CLASS_ENTRY(ce, "SampleFirstClass", sample_first_class_function_entries);
	sample_first_class_entry	= zend_register_internal_class(&ce TSRMLS_CC);
	zend_class_implements(sample_first_class_entry TSRMLS_CC, 1, sample_first_interface_entry);
	
	if ( FAILURE == sample_first_class_register_constants(sample_first_class_entry) ) 
		return FAILURE;
	
	h	= &sample_second_class_object_handlers;
	sample_second_class_object_handlers	= *zend_get_std_object_handlers();
	h->has_dimension	= sample_second_class_handler_has_dimension;
	h->read_dimension	= sample_second_class_handler_read_dimension;
	h->write_dimension	= sample_second_class_handler_write_dimension;
	h->unset_dimension	= sample_second_class_handler_unset_dimension;

	INIT_CLASS_ENTRY(ce, "SampleSecondClass", sample_second_class_function_entries);
	sample_second_class_entry	= zend_register_internal_class(&ce TSRMLS_CC);
	sample_second_class_entry->create_object	= sample_second_class_sc_create;

	return SUCCESS;
}
static void sample_register_constant(INIT_FUNC_ARGS) {
	zend_constant	c;

	ZVAL_DOUBLE(&c.value, 1.1);
	c.flags			= CONST_CS | CONST_PERSISTENT;
	c.name			= pestrdup("SAMPLE_VERSION", 1);
	c.name_len		= sizeof("SAMPLE_VERSION");
	c.module_number	= module_number;
	zend_register_constant(&c TSRMLS_CC);
}
ZEND_MODULE_GLOBALS_CTOR_D(sample)
{
	SAMPLE_G(counter)	= 0;
}
ZEND_MODULE_GLOBALS_DTOR_D(sample)
{
}

static zend_bool sample_auto_global_callback(const char *name, uint name_len TSRMLS_DC) {
	zval	*z;
	int		i;

	MAKE_STD_ZVAL(z)
	array_init(z);
	for ( i = 0; i < 1000; i ++ ) 
		add_next_index_long(z, i);
	ZEND_SET_SYMBOL(&EG(symbol_table), "_SAMPLE_G", z);

	return 0;
}

PHP_MINIT_FUNCTION(sample)
{
	le_sample_descriptor			= zend_register_list_destructors_ex(sample_descriptor_dtor, NULL, SAMPLE_DESCRIPTOR_RES_NAME, module_number);
	le_sample_descriptor_persist	= zend_register_list_destructors_ex(NULL, sample_descriptor_persist_dtor, SAMPLE_DESCRIPTOR_RES_NAME, module_number);
	if ( FAILURE == sample_register_first_class(INIT_FUNC_ARGS_PASSTHRU) )
		return FAILURE;
	
	sample_register_constant(INIT_FUNC_ARGS_PASSTHRU);

#ifdef ZTS
	ts_allocate_id(&sample_globals_id, sizeof(zend_sample_globals), (ts_allocate_ctor)ZEND_MODULE_GLOBALS_CTOR_N(sample), NULL);
#else
	sample_globals_ctor(&sample_globals TSRMLS_CC);
#endif
	REGISTER_INI_ENTRIES();

	zend_register_auto_global("_SAMPLE_G", sizeof("_SAMPLE_G") - 1, 0 
#ifdef ZEND_ENGINE_2
		, sample_auto_global_callback
#endif
		TSRMLS_CC);
	return SUCCESS;
}

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(sample)
{
#ifndef ZTS
	sample_globals_dtor(&sample_globals TSRMLS_CC);
#endif
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request start */
/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(sample)
{
#ifndef ZEND_ENGINE_2
	sample_auto_global_callback("_SAMPLE_G", sizeof("_SAMPLE_G") - 1);
#endif
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request end */
/* {{{ PHP_RSHUTDOWN_FUNCTION
 */
PHP_RSHUTDOWN_FUNCTION(sample)
{
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(sample)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "sample support", "enabled");
	php_info_print_table_end();

	/* Remove comments if you have entries in php.ini
	DISPLAY_INI_ENTRIES();
	*/
}
/* }}} */

PHP_FUNCTION(sample_long)
{
	RETURN_LONG(42);
	php_printf("I will never be reached.\n");
}

PHP_FUNCTION(sample_array_range) {
	if ( return_value_used ) {
		int	i;
		array_init(return_value);
		for ( i = 0; i < 1000; i ++ ) 
			add_next_index_long(return_value, i);
		return ;
	} else {
		php_error_docref(NULL TSRMLS_CC, E_NOTICE, "Static return-only function called without processing output");
		RETURN_NULL();
	}
}

#if (PHP_MAJOR_VERSION > 5) || (PHP_MAJOR_VERSION == 5 && PHP_MINOR_VERSION > 0 )
PHP_FUNCTION(sample_reference_a)
{
	zval	**a_ptr, *a;

	if ( zend_hash_find(&EG(symbol_table), "a", sizeof("a"), (void **)&a_ptr) == SUCCESS ) {
		a	= *a_ptr;
	} else {
		ALLOC_INIT_ZVAL(a);
		zend_hash_add(&EG(symbol_table), "a", sizeof("a"), &a, sizeof(zval *), NULL);
	}

	zval_ptr_dtor(return_value_ptr);
	if ( !Z_ISREF_P(a) && Z_REFCOUNT_P(a) > 1 ) {
		zval	*newa;
		MAKE_STD_ZVAL(newa);
		*newa	= *a;
		zval_copy_ctor(newa);
		Z_UNSET_ISREF_P(newa);
		Z_SET_REFCOUNT_P(newa, 1);
		zend_hash_update(&EG(symbol_table), "a", sizeof("a"), &newa, sizeof(zval *), NULL);

		a		= newa;
	}

	Z_SET_ISREF_P(a);
	Z_SET_REFCOUNT_P(a, Z_REFCOUNT_P(a) + 1);
	*return_value_ptr	= a;
}
#endif

PHP_FUNCTION(sample_byref_compile)
{
	zval	*a;
	int		addtl_len	= sizeof(" (modified by ref!)") - 1;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "z", &a) == FAILURE ) {
		RETURN_NULL();
	}

	if ( !Z_ISREF_P(a) ) 
		RETURN_NULL();
	
	Z_STRVAL_P(a)	= erealloc(Z_STRVAL_P(a), Z_STRLEN_P(a) + addtl_len + 1);
	memcpy(Z_STRVAL_P(a) + Z_STRLEN_P(a), " (modified by ref!)", addtl_len + 1);
	Z_STRLEN_P(a)	+= addtl_len;
	RETURN_NULL();
}

PHP_FUNCTION(sample_hello_world)
{
	char	*name;
	int		name_len;
	char	*greeting		= "Mr./Mrs.";
	int		greeting_len	= sizeof("Mr./Mrs.") - 1;

	if ( FAILURE == zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "s|s!", &name, &name_len, &greeting, &greeting_len) ) 
		RETURN_NULL();
	
	php_printf("Hello ");
	PHPWRITE(greeting, greeting_len);
	php_printf(" ");
	PHPWRITE(name, name_len);
	php_printf("!\n");
	
	RETURN_NULL();
}

/* 拷贝自Zend/zend_hash.c */
void zend_hash_display_string(const HashTable *ht)
{
	Bucket *p;
	uint i;

	if (UNEXPECTED(ht->nNumOfElements == 0)) {
		zend_output_debug_string(0, "The hash is empty");
		return;
	}
	for (i = 0; i < ht->nTableSize; i++) {
		p = ht->arBuckets[i];
		while (p != NULL) {
			zend_output_debug_string(0, "%s[0x%lX] <==> %s", p->arKey, p->h, (char *)p->pData);
			p = p->pNext;
		}
	}

	p = ht->pListTail;
	while (p != NULL) {
		zend_output_debug_string(0, "%s[hash = 0x%lX, pointer = %p] <==> %s[pointer = %p]", p->arKey, p->h, p->arKey, (char *)p->pData, p->pData);
		p = p->pListLast;
	}
}
PHP_FUNCTION(sample_ht)
{
	HashTable	*ht0;
	char		*key;
	char		*value;
	void		*pDest;

	key		= emalloc(16);
	value	= emalloc(32);

	ALLOC_HASHTABLE(ht0);
	zend_hash_init(ht0, 50, NULL, NULL, 0);

	strcpy(key, "ABCDEFG");
	strcpy(value, "0123456789");

	printf("key: %p %s\n", key, key);
	printf("value: %p %s\n", value, value);

	zend_hash_add(ht0, key, 8, value, 11, &pDest);

	printf("pDest: %p\n", pDest);

	zend_hash_display_string(ht0);

	zend_hash_destroy(ht0);
	FREE_HASHTABLE(ht0);

	efree(value);
	efree(key);

	RETURN_NULL();
}

PHP_FUNCTION(sample_array_copy)
{
	zval	*a1, *a2, **z;
	char	*key;
	int		key_len;
	ulong	h;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "aas", &a1, &a2, &key, &key_len) == FAILURE ) {
		RETURN_FALSE;
	}

	h	= zend_get_hash_value(key, key_len + 1);

	if ( zend_hash_quick_find(Z_ARRVAL_P(a1), key, key_len + 1, h, (void **)&z) == FAILURE ) {
		RETURN_FALSE;
	}

	Z_SET_REFCOUNT_PP(z, Z_REFCOUNT_PP(z) + 1);
	Z_SET_ISREF_PP(z);
	zend_hash_quick_update(Z_ARRVAL_P(a2), key, key_len + 1, h, z, sizeof(zval *), NULL);

	RETURN_TRUE;
}

static zend_bool sample_array_copy_assoc_only_merge_check(HashTable *ht, void *src_data, zend_hash_key *hash_key, void *pParam) {
	return (hash_key->arKey && hash_key->nKeyLength);
}
PHP_FUNCTION(sample_array_copy_assoc_only) 
{
	zval	*a1, *a2;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "aa", &a1, &a2) == FAILURE ) {
		RETURN_FALSE;
	}

	zend_hash_merge_ex(Z_ARRVAL_P(a2), Z_ARRVAL_P(a1), ZVAL_COPY_CTOR, sizeof(zval *), sample_array_copy_assoc_only_merge_check, NULL);

	RETURN_TRUE;
}

static int sample_array_iterate_print_cb(zval **z TSRMLS_DC) {
	zval	tmp	= **z;

	zval_copy_ctor(&tmp);
	INIT_PZVAL(&tmp);
	convert_to_string(&tmp);

	php_printf("The value is: ");
	PHPWRITE(Z_STRVAL(tmp), Z_STRLEN(tmp));
	php_printf("\n");

	zval_dtor(&tmp);
	return ZEND_HASH_APPLY_KEEP;
}
PHP_FUNCTION(sample_array_iterate_print)
{
	zval	*z;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "a", &z) == FAILURE ) {
		RETURN_FALSE;
	}

	zend_hash_apply(Z_ARRVAL_P(z), (apply_func_t)sample_array_iterate_print_cb TSRMLS_CC);
	RETURN_TRUE;
}

static int sample_array_iterate_print_key_cb(zval **z TSRMLS_DC, int num_args, va_list args, zend_hash_key *hash_key) {
	zval	tmp	= **z;

	zval_copy_ctor(&tmp);
	INIT_PZVAL(&tmp);
	convert_to_string(&tmp);

	php_printf("The value of ");
	if ( hash_key->arKey && hash_key->nKeyLength ) {
		PHPWRITE(hash_key->arKey, hash_key->nKeyLength);
	} else {
		php_printf("%d", hash_key->h);
	}
	php_printf(" is: ");
	PHPWRITE(Z_STRVAL(tmp), Z_STRLEN(tmp));
	php_printf("\n");

	zval_dtor(&tmp);
	return ZEND_HASH_APPLY_KEEP;
}
PHP_FUNCTION(sample_array_iterate_print_key)
{
	zval	*z;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "a", &z) == FAILURE ) {
		RETURN_FALSE;
	}
	
	zend_hash_apply_with_arguments(Z_ARRVAL_P(z) TSRMLS_CC, (apply_func_args_t)sample_array_iterate_print_key_cb, 0);
	RETURN_TRUE;
}

PHP_FUNCTION(sample_array_iterate_move_forward) {
	zval		*z, tmp, **tmp_pp;
	HashTable	*hta;
	char		*key;
	uint		nKeyLength;
	ulong		idx;
	int			type;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "a", &z) == FAILURE ) {
		RETURN_FALSE;
	}

	hta	= Z_ARRVAL_P(z);

	for ( zend_hash_internal_pointer_reset(hta);
			SUCCESS == zend_hash_has_more_elements(hta);
			zend_hash_move_forward(hta) ) {
		type	= zend_hash_get_current_key_ex(hta, &key, &nKeyLength, &idx, 0, NULL);

		if ( HASH_KEY_NON_EXISTANT == type || zend_hash_get_current_data(hta, (void **)&tmp_pp) == FAILURE ) {
			continue;
		}

		tmp		= **tmp_pp;
		zval_copy_ctor(&tmp);
		INIT_PZVAL(&tmp);
		convert_to_string(&tmp);

		php_printf("The value of ");
		if ( type == HASH_KEY_IS_STRING ) {
			PHPWRITE(key, nKeyLength - 1);
		} else {
			php_printf("%d", idx);
		}
		php_printf(" is: ");
		PHPWRITE(Z_STRVAL(tmp), Z_STRLEN(tmp));
		php_printf("\n");

		zval_dtor(&tmp);
	}

	RETURN_TRUE;
}

static int sample_fname_compare(Bucket **p1, Bucket **p2 TSRMLS_DC) {
	zend_function	*zf1, *zf2;
	zf1	= (zend_function *)(*p1)->pData;
	zf2	= (zend_function *)(*p2)->pData;
	return strcasecmp(zf1->common.function_name, zf2->common.function_name);
}
PHP_FUNCTION(sample_funcname_sort)
{
	zend_function	*zf;

	if ( zend_hash_minmax(EG(function_table), (compare_func_t)sample_fname_compare, 0, (void **)&zf TSRMLS_CC) == SUCCESS )
		php_printf("Min function: %s\n", zf->common.function_name);
	if ( zend_hash_minmax(EG(function_table), (compare_func_t)sample_fname_compare, 1, (void **)&zf TSRMLS_CC) == SUCCESS )
		php_printf("Max function: %s\n", zf->common.function_name);
	
	RETURN_TRUE;
}

PHP_FUNCTION(sample_array)
{
	zval	*subarray;

	array_init(return_value);
	add_assoc_long(return_value, "life", 42);
	add_index_bool(return_value, 123, 1);
	add_next_index_double(return_value, 3.1415926535);
	add_next_index_string(return_value, "Foo", 1);
	add_next_index_string(return_value, estrdup("Bar"), 0);

	MAKE_STD_ZVAL(subarray);
	array_init(subarray);
	add_next_index_long(subarray, 1);
	add_next_index_long(subarray, 20);
	add_next_index_long(subarray, 300);
	add_index_zval(return_value, 444, subarray);
}

PHP_FUNCTION(sample_fopen)
{
	sample_descriptor_data_t	*sddp;
	FILE						*fp;
	char						*filename, *mode;
	int							filename_len, mode_len;
	zend_bool					persist	= 1;
	char						*hash_key;
	int							hash_key_len;
	int							rsrc_l;
	zend_rsrc_list_entry		*le_p;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "ss|b", 
			&filename, &filename_len, 
			&mode, &mode_len, &persist) == FAILURE ) {
		RETURN_NULL();
	}

	if ( !filename_len || !mode_len ) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Invalid filename or mode length");
		RETURN_FALSE;
	}

	hash_key_len	= spprintf(&hash_key, 0, "sample_descriptor:%s:%s", filename, mode);
	if ( zend_hash_find(&EG(persistent_list), hash_key, hash_key_len + 1, (void **)&le_p) == SUCCESS ) {
		rsrc_l	= ZEND_REGISTER_RESOURCE(return_value, le_p->ptr, le_sample_descriptor_persist);
	} else {
		fp	= fopen(filename, mode);
		if ( !fp ) {
			efree(hash_key);
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "Unable to open %s using mode %s", 
					filename, mode);
			RETURN_FALSE;
		}

		sddp		= pemalloc(sizeof(sample_descriptor_data_t), persist);
		sddp->fname	= pestrdup(filename, persist);
		sddp->fp	= fp;
		rsrc_l		= ZEND_REGISTER_RESOURCE(return_value, sddp, persist ? le_sample_descriptor_persist : le_sample_descriptor);
		if ( persist ) {
			zend_rsrc_list_entry	le;

			le.type	= le_sample_descriptor_persist;
			le.ptr	= sddp;
			zend_hash_update(&EG(persistent_list), hash_key, hash_key_len + 1, (void *)&le, sizeof(zend_rsrc_list_entry), NULL);
		}
	}
	efree(hash_key);
	RETURN_RESOURCE(rsrc_l);
}

PHP_FUNCTION(sample_fwrite)
{
	sample_descriptor_data_t	*sddp;
	zval						*file_resource;
	char						*data;
	int							data_len;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "rs", 
			&file_resource, &data, &data_len) == FAILURE ) {
		RETURN_FALSE;
	}
	ZEND_FETCH_RESOURCE2(sddp, sample_descriptor_data_t *, &file_resource, -1, 
		SAMPLE_DESCRIPTOR_RES_NAME, le_sample_descriptor, le_sample_descriptor_persist);
#if ZEND_DEBUG
php_printf("FILE * pointer: %p\n", sddp->fp);
#endif
	RETURN_LONG(fwrite(data, 1, data_len, sddp->fp));
}

PHP_FUNCTION(sample_fclose)
{
	sample_descriptor_data_t	*sddp;
	zval						*file_resource;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &file_resource) == FAILURE ) {
		RETURN_FALSE;
	}

	ZEND_FETCH_RESOURCE2(sddp, sample_descriptor_data_t *, &file_resource, -1, SAMPLE_DESCRIPTOR_RES_NAME, le_sample_descriptor, le_sample_descriptor_persist);
	zend_hash_index_del(&EG(regular_list), Z_RESVAL_P(file_resource));

	RETURN_TRUE;
}

PHP_FUNCTION(sample_fname)
{
	sample_descriptor_data_t	*sddp;
	zval	*file_resource;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &file_resource) == FAILURE ) {
		RETURN_FALSE;
	}

	ZEND_FETCH_RESOURCE2(sddp, sample_descriptor_data_t *, &file_resource, -1, SAMPLE_DESCRIPTOR_RES_NAME, le_sample_descriptor, le_sample_descriptor_persist);
	RETURN_STRING(sddp->fname, 1);
}

PHP_FUNCTION(sample_frsrc_info)
{
	zval					*file_resource;
	zend_rsrc_list_entry	*le;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "r", &file_resource) == FAILURE ) {
		RETURN_FALSE;
	}

	zend_hash_index_find(&EG(regular_list), Z_RESVAL_P(file_resource), (void **)&le);
	php_printf("zval-refcount: %d, zval-isref: %s, leptr: %p, ptr: %p, refcount: %d, type: %s\n", 
		Z_REFCOUNT_P(file_resource), Z_ISREF_P(file_resource) ? "TRUE" : "FALSE", 
		le, le->ptr, le->refcount, 
		le->type == le_sample_descriptor 
			? "le_sample_descriptor"
			: ( le->type == le_sample_descriptor_persist
				? "le_sample_descriptor_persist"
				: "unknown"
			));
	RETURN_NULL();
}

PHP_FUNCTION(sample_new)
{
	int					argc	= ZEND_NUM_ARGS();
	zval				***argv	= safe_emalloc(sizeof(zval **), argc, 0);
	zend_class_entry	**ce;		/* 译注: 这里在译者的环境(php-5.4.9)是二级间访 */

	/* 数组方式读取所有传入参数 */
	if ( argc == 0 || 
			zend_get_parameters_array_ex(argc, argv) == FAILURE ) {
		efree(argv);
		WRONG_PARAM_COUNT;
	}

	/* 隔离第一个参数(隔离为了使下面的类型转换不影响原始数据) */
	SEPARATE_ZVAL(argv[0]);
	/* 将第一个参数转换为字符串类型, 并转为小写(因为php的类名是不区分大小写的) */
	convert_to_string(*argv[0]);
	php_strtolower(Z_STRVAL_PP(argv[0]), Z_STRLEN_PP(argv[0]));
	/* 在类的HashTable中查找提供的类是否存在, 如果存在, ce中就得到了对应的zend_class_entry * */
	if ( zend_hash_find(EG(class_table), Z_STRVAL_PP(argv[0]), Z_STRLEN_PP(argv[0]) + 1, (void **)&ce) == FAILURE ) {
		php_error_docref(NULL TSRMLS_CC, E_WARNING, "Class %s does not exist.", Z_STRVAL_PP(argv[0]));
		zval_ptr_dtor(argv[0]);
		efree(argv);
		RETURN_FALSE;
	}

	/* 将返回值初始化为查找到的类的对象 */
	object_init_ex(return_value, *ce);
	/* 检查类是否有构造器 */
	if ( zend_hash_exists(&(*ce)->function_table, Z_STRVAL_PP(argv[0]), Z_STRLEN_PP(argv[0]) + 1) ) {
#define DYNAMIC_CONSTRUCTOR
#ifndef DYNAMIC_CONSTRUCTOR
		zval	*ctor;
#endif
		zval	*dummy = NULL;

#ifndef DYNAMIC_CONSTRUCTOR
		/* 将ctor构造为一个数组, 对应的用户空间形式为: array(argv[0], argv[0]), 
		 * 实际上对应于用户空间调用类的静态方法时$funcname的参数形式:
		 * array(类名, 方法名)
		 */
		MAKE_STD_ZVAL(ctor);
		array_init(ctor);
		zval_add_ref(argv[0]);
		add_next_index_zval(ctor, *argv[0]);
		zval_add_ref(argv[0]);
		add_next_index_zval(ctor, *argv[0]);
#endif
		/* 调用函数 */
		if ( call_user_function_ex(&(*ce)->function_table,
#ifndef DYNAMIC_CONSTRUCTOR
				NULL, ctor, 
#else
				&return_value, *argv[0], 
#endif
				&dummy, argc - 1, argv + 1, 0, NULL TSRMLS_CC) == FAILURE ) {
			php_error_docref(NULL TSRMLS_CC, E_WARNING, "Unable to call constructor");
		}
		/* 如果有返回值直接析构丢弃 */
		if ( dummy ) {
			zval_ptr_dtor(&dummy);
		}
#ifndef DYNAMIC_CONSTRUCTOR
		/* 析构掉临时使用(用来描述所调用方法名)的数组 */
		zval_ptr_dtor(&ctor);
#endif
	}
	/* 析构临时隔离出来的第一个参数(类名) */
	zval_ptr_dtor(argv[0]);
	/* 释放实参列表空间 */
	efree(argv);
}

PHP_FUNCTION(sample_getclassname)
{
	zval		*z;

	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "o", &z) == FAILURE ) {
		RETURN_NULL();
	}
	RETURN_STRINGL(Z_OBJCE_P(z)->name, Z_OBJCE_P(z)->name_length, 1);
}

PHP_FUNCTION(sample_classhint)
{
	zval		*z;
	if ( zend_parse_parameters(ZEND_NUM_ARGS() TSRMLS_CC, "O", &z, sample_first_class_entry) == FAILURE ) {
		RETURN_NULL();
	}
	RETURN_STRINGL(Z_OBJCE_P(z)->name, Z_OBJCE_P(z)->name_length, 1);
}

PHP_FUNCTION(sample_counter)
{
	RETURN_LONG(++SAMPLE_G(counter));
}

PHP_FUNCTION(sample_greeting)
{
	const char	*greeting	= INI_STR("sample.greeting");
	php_printf("%s\n", greeting);
	php_printf("-----------------print globals-----------\n");
	php_printf("greeting: %s\n", SAMPLE_G(greeting));
	php_printf("long_value: %ld\n", SAMPLE_G(long_value));
	php_printf("double_value: %f\n", SAMPLE_G(double_value));
	php_printf("bool_value: %d\n", SAMPLE_G(bool_value));
}


























































/* The previous line is meant for vim and emacs, so it can correctly fold and 
   unfold functions in source code. See the corresponding marks just before 
   function definition, where the functions purpose is also documented. Please 
   follow this convention for the convenience of others editing your code.
*/


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
